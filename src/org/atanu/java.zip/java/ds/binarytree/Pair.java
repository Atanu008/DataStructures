package org.atanu.java.ds.binarytree;

 public class Pair{

	TreeNode node;
	int dist;

	public Pair(TreeNode node, int dist) {
		super();
		this.node = node;
		this.dist = dist;
	}


}
