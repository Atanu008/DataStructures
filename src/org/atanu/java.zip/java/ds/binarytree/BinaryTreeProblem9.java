package org.atanu.java.ds.binarytree;

public class BinaryTreeProblem9 {

	public static boolean hasPathSum(TreeNode root , int sum) {

		// this will only execute for empty tree
		if(root == null) {
			return false;
		}
		
		// Base Case . For leaf Node
		if (root.left == null && root.right == null) {
			if(root.data == sum) {
				return true;
			}
		}

		return hasPathSum(root.left, sum - root.data) || hasPathSum(root.right, sum - root.data);


	}
	public static void main(String[] args) {
		
		/* Construct below tree
        1
      /   \
     /     \
    2       3
   / \      / \
  /   \    /   \
 4     5  6     7
         / \
        /   \
       8     9
		 */
		
		int sum = 11;

		TreeNode root = new TreeNode(1);
		root.left = new TreeNode(2);
		root.right = new TreeNode(3);
		root.left.left = new TreeNode(4);
		root.left.right = new TreeNode(5);
		root.right.left = new TreeNode(6);
		root.right.right = new TreeNode(7);
		root.right.left.left = new TreeNode(8);
		root.right.left.right = new TreeNode(9);
		
		 if (hasPathSum(root, sum)) 
	            System.out.println("There is a root to leaf path with sum " + sum); 
	        else
	            System.out.println("There is NO root to leaf path with sum " + sum); 
	}

}
