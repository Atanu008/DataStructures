package org.atanu.java.ds.graph;

public class Edge {

	int source , dest;

	public Edge(int source, int dest) {
		super();
		this.source = source;
		this.dest = dest;
	}
	
}
